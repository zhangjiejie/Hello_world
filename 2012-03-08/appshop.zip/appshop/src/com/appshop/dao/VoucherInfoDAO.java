package com.appshop.dao;

import com.appshop.model.VoucherInfo;

public interface VoucherInfoDAO extends IBaseDAO<VoucherInfo> {

}

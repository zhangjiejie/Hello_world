package com.appshop.dao;

import com.appshop.model.User;

public interface UserDAO extends IBaseDAO<User> {

}

package com.appshop.dao;

import com.appshop.model.MerchandiseInfo;

public interface MerchandiseInfoDAO extends IBaseDAO<MerchandiseInfo> {

}

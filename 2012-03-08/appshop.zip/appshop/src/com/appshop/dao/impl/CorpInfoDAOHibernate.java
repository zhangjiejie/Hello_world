package com.appshop.dao.impl;

import com.appshop.dao.CorpInfoDAO;
import com.appshop.model.CorpInfo;

public class CorpInfoDAOHibernate extends BaseHibernateDaoSupport<CorpInfo> implements CorpInfoDAO {

	
}

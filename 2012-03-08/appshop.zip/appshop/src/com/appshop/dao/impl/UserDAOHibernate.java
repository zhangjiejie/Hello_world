package com.appshop.dao.impl;

import com.appshop.dao.UserDAO;
import com.appshop.model.User;

public class UserDAOHibernate extends BaseHibernateDaoSupport<User> implements UserDAO {

	
}

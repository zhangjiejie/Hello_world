package com.appshop.dao.impl;

import com.appshop.dao.VoucherInfoDAO;
import com.appshop.model.VoucherInfo;

public class VoucherInfoDAOHibernate extends BaseHibernateDaoSupport<VoucherInfo> implements VoucherInfoDAO {

	
}

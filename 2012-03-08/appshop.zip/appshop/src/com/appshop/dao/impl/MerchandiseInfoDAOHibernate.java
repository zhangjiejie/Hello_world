package com.appshop.dao.impl;

import com.appshop.dao.MerchandiseInfoDAO;
import com.appshop.model.MerchandiseInfo;

public class MerchandiseInfoDAOHibernate extends BaseHibernateDaoSupport<MerchandiseInfo> implements MerchandiseInfoDAO {

	
}

package com.appshop.dao;

import com.appshop.model.CorpInfo;

public interface CorpInfoDAO extends IBaseDAO<CorpInfo>{

}
